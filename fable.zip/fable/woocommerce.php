<?php		
		get_header(); 
		if(have_posts()) woocommerce_content();
		get_footer(); 